console.log("varsha");
 $(function() {
 
    // Setup form validation on the #register-form element
    $("#register-form1").validate({
    
        // Specify the validation rules
        rules: {
           
            Email: 
            {
                required: true,
                email:true
                
            }
           
           
        },
        
        // Specify the validation error messages
        messages: {
          
            Email: 
            {   
                required: "Please Enter Email Address",
                email:"Please Enter Valid Email Address"
                
            }
            
          
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });