console.log("here");
$(function() {
    $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^([a-zA-Z])[a-zA-Z_-]*[\w_-]*[\S]$|^([a-zA-Z])[0-9_-]*[\S]$|^[a-zA-Z]*[\S]$/.test(value);
}, "Username Should Starts With An Alphabet and Contains No special Characters Other Than Underscore Or Dash.");


   $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^[A-Za-z]+$/.test(value);
}, "First name should be alpha characters only.");

    $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^[A-Za-z]+$/.test(value);
}, "Last name should be alpha characters only.");
    // Setup form validation on the #register-form element
    $("#register-form").validate({

        // Specify the validation rules
        rules: {
            firstname:{
                required: true,
                minlength: 3,
                maxlength: 20,
                regx:/^[A-Za-z]+$/
            },
            lastname:
            {
                required: true,
                minlength: 3,
                maxlength: 20,
                regx:/^[A-Za-z]+$/
            },
            email:
            {
                required: true,
                email: true,
            },
            username:
             {
                required: true,
                minlength: 3,
                regx:/^([a-zA-Z])[a-zA-Z_-]*[\w_-]*[\S]$|^([a-zA-Z])[0-9_-]*[\S]$|^[a-zA-Z]*[\S]$/
            },
            password:
            {
                required: true,
                minlength: 8
            },
            user_type: {
                required:true
            }
        },
         errorElement: "div",
        // Specify the validation error messages
        messages: {
            firstname:
            {
                required:"Please Enter Your First Name",
                minlength:"Please Enter Atleast Three Character",
                maxlength: "You Can Enter Maximum 20 Character",
                 regx:"First name should be alpha characters only."
            },
            lastname:
            {
                required: "Please Enter Your Last Name",
                minlength:"Please Enter Atleast Three Character",
                maxlength: "You Can Enter Maximum 20 Character",
                regx:"Last name should be alpha characters only."
            },
            email:
            {
                required: "Please Enter Email Address",
                email:"Please Enter A Valid Email Address",
               // Remote:"hi"
            },
            username:
            {
             required: "Please Enter Username",
             minlength:"Please Enter Atleast Three Character",
            regx:"Username Should Starts With An Alphabet and Contains No special Characters Other Than Underscore Or Dash."
            },

            password: {
                required: "Please provide A password",
                minlength: "Your password must be at least 8 characters long"
            },
            user_type: {
                required:"Please select user type."
            }
        },

        submitHandler: function(form) {
            form.submit();
        }
    });

  });
