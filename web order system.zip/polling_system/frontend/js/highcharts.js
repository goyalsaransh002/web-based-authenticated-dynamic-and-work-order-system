//console.log("hi");
console.log("hello world");
$(function () {
var d = $('#container').attr('data-tags');

    //var d1 = [{"name":"Tokyo","data":"3.0"},{"name":"NewYork","data":"2.0"}, {"name":"Berlin","data":"3.5"},{"name":"London","data":"1.5"}]
    console.log(d);
    var d2=  JSON.parse(d);
   // console.log(d2);
    

    var name = Array();
    var data = Array();
    var dataArrayFinal = Array();
    for(i=0;i<d2.length;i++) { 
     name[i] = d2[i].name; 
    data[i] = d2[i].data;  
    }
        //console.log(data);
        for(j=0;j<name.length;j++) { 
        var temp = new Array(name[j],parseInt(data[j])); 
        dataArrayFinal[j] = temp;     
        }


      $('#container').highcharts({  
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false
        },
        credits: {
            enabled: false
        },

        title: {
            text: 'poll result'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: '#000000',
                    connectorColor: '#000000',
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
            }
        },
        series: [{
            type: 'pie',
            name: 'Result share',             
            data: dataArrayFinal
            //xyz
         /*  data: d  */   
            
        }]
        
    });
});