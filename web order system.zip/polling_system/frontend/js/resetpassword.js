console.log("varsha");
 $(function() {
        
  
    // Setup form validation on the #register-form element
    $("#register-form1").validate({
    
        // Specify the validation rules
        rules: {
           
            password:
             {
                required: true,
                minlength:8
               
            }
        },
        
        // Specify the validation error messages
        messages: {
          
            password: {
                required: "Please provide A password",
                minlength:"Please Enter Atleast 8 Character Password"
                
            }
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });