 console.log("varshu");
 $(function() {

$(".forms").validate({
    
        // Specify the validation rules
       
        rules: {
            
            title:
            {  
                required: true,
               
            },
            captcha:
            {  
              required: true
             
            }
          
        },
         
        // Specify the validation error messages
        messages: {
            title:
            { 
                required:"Please Select Atleast One Option"
            },
            captcha:
            { 
              required: "Please Enter Code"    
            }
            
         
        },
    /*   errorPlacement: function(label, element) {
         if("title" == element.attr("name")){
        error.appendTo($('#errorbox'));
    }
  },*/
   
       
        submitHandler: function(form) {
            form.submit();
        },
       
   
    });

  });
