
$(document).ready(function(){
  $(".radio_option").click(function(){
    $("#captcha").hide();
  });
});