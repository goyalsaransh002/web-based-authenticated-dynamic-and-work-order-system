function myfunction1()
{
	var Email=document.forms['myform1']['Email'].value;
	 var emailRegexStr = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  	 var isvalid = emailRegexStr.test(Email);
	// var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
	 var password=document.forms['myform1']['password'].value;
	 //var reg1="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		if(Email=="")
	{
		alert('Required Email');
		return false;
	}
	if (!isvalid) {
 		alert('Invalid Email Address!');
 		return false;
 	}
	/* if (!reg.test(login))
	 {
		alert("invalid email");
		return false;
	} */

	if(document.myform1.password.value=="")
	{
		alert('Please Enter Password');
		return false;
	}

	return true;
}
