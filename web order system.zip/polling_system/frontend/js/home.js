
	function myfunction(name)
	{	
				
		for (var i=0; i<name.title.length; i++)
		 {
			if (name.title[i].checked)
			break;
		 }

		if (i==name.title.length)
		{
			return alert("Please Select Atleast One Option");
		}
		if(name.captcha.value=="" || name.captcha.value==null)
		{
			alert("Please Enter Code");
			return false;
		}
	/*	var getval =document.getElementById("cap_val").innerHTML;
		alert(getval);
		return false;*/
		if(name.captcha.value != name.cap_val.value)
		{
			alert("hi");
			return false;
		}
		/* document.form.submit();*/

		return true;
	
	}	
	