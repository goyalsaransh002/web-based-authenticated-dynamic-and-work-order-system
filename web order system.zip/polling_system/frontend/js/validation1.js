console.log("varsha1");
 $(function() {
    $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^([a-zA-Z])[a-zA-Z_-]*[\w_-]*[\S]$|^([a-zA-Z])[0-9_-]*[\S]$|^[a-zA-Z]*[\S]$/.test(value);
}, "Username Should Starts With An Alphabet and Contains No special Characters Other Than Underscore Or Dash.");


   $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^[A-Za-z]+$/.test(value);
}, "First name should be alpha characters only.");
    $.validator.addMethod("regx", function(value, username, regexpr) {
    return /^[A-Za-z]+$/.test(value);
}, "Last name should be alpha characters only.");
    // Setup form validation on the #register-form element
    $("#register-form1").validate({

        // Specify the validation rules
        rules: {

            Email:
            {
                required: true,
                email: true
            },

            password:
             {
                required: true

            }
        },

        // Specify the validation error messages
        messages: {

            Email:
            {
                required: "Please Enter Email Address",
                email:"Please Enter A Valid Email Address"
            },

            password: {
                required: "Please provide A password"

            }
        },

        submitHandler: function(form) {
            form.submit();
        }
    });

  });
