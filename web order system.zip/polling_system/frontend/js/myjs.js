function myfunction()
{
	var firstname=document.forms['myform']['firstname'].value;

	name=firstname.trim();
	maxlength=15;
	var lastname=document.forms['myform']['lastname'].value;
	var username=document.forms['myform']['username'].value;

	var Email=document.forms['myform']['email'].value;
	 var emailRegexStr = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  	 var isvalid = emailRegexStr.test(Email);
	var password=document.forms['myform']['password'].value;
		minlength=7;

	if(firstname=="" || firstname==null)
	{
		alert("First Name Should Be Filled Out");
		return false;
	}
	if(!isNaN(firstname))
	{
		alert("First Name Should Be Alpha Characters Only.");
		return false;
	}

	if(lastname=="" || lastname==null)
	{
		alert("Last Name Should Be Filled Out");
		return false;
	}


	if(document.myform.lname.value.trim()=="")
	{
		alert("Please Do Not Enter Blank Space");
		return false;
	}
	if(!isNaN(lastname))
	{
		alert("Last Name Should Be Alpha Characters Only.");
		return false;
	}
	if(username=="")
	{
		alert('Username Required');
		return false;
	}
	if(Email=="")
	{
		alert('Required Email');
		return false;
	}
	if (!isvalid) {
 		alert('Invalid Email Address!');
 		return false;
 	}

	if(document.myform.password.value.length<minlength)
	{
		alert("Please Enter Atleast 7 Characters Password");
		return false;
	}
	return true;
}
