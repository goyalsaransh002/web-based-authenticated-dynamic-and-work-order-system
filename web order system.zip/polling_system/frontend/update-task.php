<?php
session_start();

header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.
//echo $_SESSION['username'];
 include "connection.php";	
?>
<?php

if(isset($_SESSION['userId']) && !empty($_SESSION['userId'])) { ?>
  <?php
    $userId = $_SESSION['userId'];
    $taskId = $_GET['id'];
    if(isset($taskId)) {
      $task = mysql_query("SELECT * FROM tasks where id='$taskId'");
      $result = mysql_fetch_assoc($task);
      $title = $result['title'];
      $description = $result['description'];
      $status = $result['status'];
      $err_flag = true;
    if(isset($_POST['add_task'])) {
        $title = mysql_real_escape_string($_POST['title']);
        $description = $_POST['description'];
        $status = $_POST['status'];

        if($err_flag) {
          $current_date = date('Y-m-d H:i:s');
          $query=mysql_query("UPDATE tasks SET status='$status',updated_at='$current_date' where id='$taskId'");
          
          if($query)
          {

            $success  = "Task has been updated successfully.";
            header("location:tasks.php");
          }
          else
          {
             $error .="Something went wrong. Unable to create task";
          }

        }
      } 
    } else {
        header("location:tasks.php");
    }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="tasks.php">Tasks</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="tasks.php">Tasks</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul><br>
    </div>
    <br>
    
    <div class="col-sm-9">
        <form method="post" action="<?php $_PHP_SELF ?>">
          <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" class="form-control" value="<?php echo $title; ?>" disabled=true>
          </div>
          <div class="form-group">
            <label for="pwd">Description:</label>
            <textarea class="form-control" rows="5" id="comment" name="description" disabled=true><?php echo $description; ?></textarea>
          </div>
          <div class="form-group">
            <?php $statusArr = array('pending'=>'Pending','progress'=>'Progress','done'=>'Done','invalid'=>'Invalid'); ?>
            <select name="status">
              <?php foreach($statusArr as $key=>$value) { ?>
                <option value="<?php echo $key; ?>" <?php if($key == $status) { ?>selected=true<?php } ?>><?php echo $value;  ?></option>
              <?php } ?>
            </select>
          </div>
  
          <button type="submit" class="btn btn-default" name="add_task">Submit</button>
        </form>
    </div>
  </div>
</div>

</nav>
</body>
</html>

<?php } else {
	header("location:login.php");
}

?>