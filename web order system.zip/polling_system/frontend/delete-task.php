<?php
session_start();
include "connection.php"; 
if(!isset($_SESSION['userId'])) 
{
	header('location:login.php');
} 
$id1=$_GET['id'];
$query=mysql_query("DELETE FROM tasks WHERE id='$id1' ");
header('location:tasks.php');
?>						
	