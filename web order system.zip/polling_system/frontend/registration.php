<?php
session_start();
include "connection.php";
header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.

?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style1.css">

		<title>Registration</title>
	</head>
	<body>
		<?php
			//Register form
			if(isset($_POST['register']))
			{

				$firstname=mysql_real_escape_string($_POST['firstname']);
				$lastname=mysql_real_escape_string($_POST['lastname']);
				$username=mysql_real_escape_string($_POST['username']);
				$Email=mysql_real_escape_string($_POST['email']);
				$userType=mysql_real_escape_string($_POST['user_type']);
				$password=$_POST['password'];
				$err_flag = true;
				$err_firstname = '';
				$err_lastname = '';
				$err_username = '';
				$err_email = '';
				$err_password = '';
				$err_usertype = '';
				$success = '';
				if($firstname=="")
				{
					$err_firstname .='Please Enter First Name';
					$err_flag = false;
				}
				elseif(!ctype_alpha(str_replace(array("'", "-"), "",$firstname)))
				{
					$err_firstname .= 'First name should be alpha characters only.';
					$err_flag = false;
				}
				else
				{
					if(strlen($firstname) < 3 OR strlen($firstname) > 20)
					{
						$err_firstname .= 'First name should be within 3-20 characters long.';
						$err_flag = false;
					}
					else
					{
						$val_name = $firstname;
					}
				}

				if($lastname=="")
				{
					$err_lastname .='Please Enter Last Name';
					$err_flag = false;
				}
				elseif(!ctype_alpha(str_replace(array("'", "-"), "", $lastname)))
				{
					$err_lastname .= 'Last name should be alpha characters only.';
					$err_flag = false;
				}
				else
				{
					if(strlen($lastname) < 3 OR strlen($lastname) > 20)
					{
						$err_lastname .= 'Last name should be within 3-20 characters long.';
						$err_flag = false;
					}
					else
					{
						$val_name1= $lastname;
					}
				}
				if($username=="")
				{
					$err_username .='Please Enter User Name';
					$err_flag = false;
				}
				elseif(!preg_match('/^([a-zA-Z])[a-zA-Z_-]*[\w_-]*[\S]$|^([a-zA-Z])[0-9_-]*[\S]$|^[a-zA-Z]*[\S]$/',$username))
				{
					$err_username .= 'Username Should Starts With An Alphabet and Contains No special Characters Other Than Underscore Or Dash.';
					$err_flag = false;
				}
				else
				{
					if(strlen($username) < 3 OR strlen($username) > 20)
					{
						$err_username .= 'Username should be within 3-20 characters long.';
						$err_flag = false;
					}
					else
					{
						$val_username= $username;
					}
				}
				if($Email=="")
				{
					$err_email .='Please Enter Email';
					$err_flag = false;
				}
				elseif(preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $Email))
				{
					$val_email = $Email;
				}
				else
				{
					$err_email = 'Please enter valid Email.';
					$err_flag = false;
				}
				if($password=="")
				{
					$err_password .='Please Enter Password';
					$err_flag = false;
				}
				elseif(!(strlen($password) < 8 OR strlen($password) > 20))
				{
					$val_password =$password;

				}
				else
				{
					$err_password = 'Password should be within 3-20 characters long.';
					//array_push($errors, "Password should be within 3-20 characters long.");
				}

				if($userType == "") {
					$err_usertype = "Please select user type.";
					$err_flag = false;
				} else {
					$userType = $userType;
				}

				if($err_flag)
				{
					//echo "select * from users where Email='$Email'";
				$dupli= mysql_num_rows(mysql_query("select * from users where Email='$Email'"));
				//print_r($dupli);
				//echo "select * from users where username='$username'";
				$dupli1= mysql_num_rows(mysql_query("select * from users where username='$username'"));
				if ($dupli)
				{
					$err_email = "Email Already Exists";

				}
				elseif($dupli1)
				{
					$err_username .= "Username Already Exists";
				}

				else
				{
					$val_password=md5($password);
					$query=mysql_query("INSERT INTO users SET firstname='$firstname',lastname='$lastname',username='$username',email='$Email',password='$val_password', user_type='$userType'");
					$id2=mysql_insert_id();

					if($query)
					{

						$success  = "User has been added successfully. Please login.";
					}
					else
					{
						 $error .="Not found your email in our database";
					}
				}
			}
			} else {
				$val_name = '';
				$val_password = '';
				$val_name1 = '';
				$val_username = '';
				$val_email = '';
				$userType = '';
				$error = '';
			}


			if(isset($_POST['login']))
			{
				$email=mysql_real_escape_string($_POST['Email']);
				$password=md5($_POST['password']);

				if (preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $email))
					{
						$val_email1 = $email;
					}
					else
					{
						$err_email1 = 'Please Enter Valid Email.';
					}
				$query=mysql_query("SELECT * FROM users WHERE Email='$email' AND password= '$password'");
				$result= mysql_fetch_assoc($query);

				if($result)
				{
					$_SESSION["userId"] = $result['id'];
					$_SESSION["user_type"] = $result['user_type'];
					if($result['user_type'] == 'admin') {
						header("location:/admin/dashboard.php");
					} else if($result['user_type'] == 'customer' || $result['user_type'] == 'worker') {
						header("location:home.php");
					}
				}
				else
				{
					if((strlen($val_email1)>0))
					{
						$err= "Email or password is incorrect";
					}

				}

			} else {
				$err = '';
				$val_email1 = "";
			}
		?>
		<div id="main">
			<div id="form1">
				<?php if(isset($error)) { ?>
					<span class="error1"><?php echo $error; ?></span>
				<?php } ?>
				<?php if(isset($success)) { ?>
					<span style="color:green;"><?php echo $success; ?></span>
				<?php } ?>
				<form name="myform" id="register-form" method="post" action="<?php $_PHP_SELF ?>">
					<div id="logo"><h2>Register Here</h2></div>
					<div id="container_1">
						<div class="content">
							<label id="label1" class="label">First Name:</label>
							<div><input type="text" class="input" id="fname" name="firstname" placeholder="Enter Your First name" value="<?php echo $val_name; ?>"  />
							<div for="fname" generated="true" class="error"></div></div>
							<?php if(isset($err_firstname)) { ?>
								<div class="error1"><?php echo $err_firstname; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<label id="label2" class="label">Last Name:</label>
							<div><input type="text" class="input" id="lname" name="lastname" placeholder="Enter Your Last name"   value="<?php echo $val_name1; ?>" />
							<div for="lname" generated="true" class="error"></div></div>
							<?php if(isset($err_lastname)) { ?>
								<div class="error1"><?php echo $err_lastname; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<label id="label3" class="label">Username:</label>
							<input type="text" class="input" id="uname" name="username" placeholder="Enter Your Username"  value="<?php echo $val_username; ?>" />
							<?php if(isset($err_username)) { ?>
								<div class="error1"><?php echo $err_username; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<label id="label4" class="label">Email:</label>
							<input type="text" class="input" id="email" name="email" placeholder="Enter Your Email" value="<?php echo $val_email; ?>" >
							<?php if(isset($err_email)) { ?>
								<div class="error1"><?php echo $err_email; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<label id="label5" class="label">Password:</label>
							<input type="password" class="input" id="password" name="password" placeholder="Enter Your Password" />
							<?php if(isset($err_password)) { ?>
								<div class="error1"><?php echo $err_password; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<label id="label5" class="label">User Type:</label>
							<select name="user_type" value="<?php echo $userType; ?>">
								<option value="">Please select user type</option>
								<option value="customer">Customer</option>
								<option value="worker">Worker</option>
							</select>
							<?php if(isset($err_usertype)) { ?>
								<div class="error1"><?php echo $err_usertype; ?></div>
							<?php } ?>
						</div>

						<div class="content">
							<input type="submit" class="content_btn" id="btn2" name="register" value="Register" >
							<input type="reset" class="content_btn" name="Reset" value="Reset">
						</div>

					</div>

				</form>
			</div>
			<div id="form2">
				<form name="myform1" action="<?php $_PHP_SELF ?>" method="post" id="register-form1">
					<div id="logo1"><h2>Login</h2></div>
					<?php if(isset($err)) { ?>
						<div class="error"><?php echo $err; ?></div>
					<?php } ?>
					<div id="container2">
							<?php if(isset($err)) { ?>
								<div class="error1"><?php print($err); ?></div>
							<?php } ?>
							<div class="content_1">
								<label class="label1">Email:</label>
								<input type="text" id="email" class="input" name="Email"  placeholder="Enter Your Email" value="<?php echo $val_email1; ?>" autofocus />
								<?php if(isset($err_email1)) { ?>
									<div class="error1" ><?php print($err_email1); ?></div>
								<?php } ?>
							</div>

							<div class="content_1">
								<label class="label1">Password:</label>
								<input type="password" name="password" class="input" placeholder="Enter Your Password" />
							</div>

							<div id="btn">
								<input type="submit" name="login" value="Login" />
							</div>
						</div>
					</form>
				</div>
			</div>


				<div id="footer">
					<div id="footer_content">
						<!-- <span>Copyright &copy; 2013 - AnkTech Softwares Pvt. Ltd. All Rights Reserved.</span> -->

					</div>
				</div>

	</body>
</html>
