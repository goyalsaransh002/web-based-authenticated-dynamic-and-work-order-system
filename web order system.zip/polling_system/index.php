<?php
	session_start();

include "frontend/connection.php";
header("location:frontend/registration.php");

 ?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="frontend/css/style.css">
	<link rel="stylesheet" type="text/css" href="frontend/css/style1.css">
	<script type="text/javascript" src="frontend/js/myjs.js"></script>

	<title>Registration</title>
</head>
<body>
	<?php

		/*
			if(empty($_SESSION['username']))
		{
			header("Location: frontend/home.php");
		}
		else
		{
			header("Loaction: frontend/home.php");
		}*/
?>
</body>
</html>
