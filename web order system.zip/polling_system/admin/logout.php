<?php
session_start(); 
unset($_SESSION['userId']);
unset($_SESSION['user_type']);
include "connection.php";

header('location: ../frontend/home.php');
?>