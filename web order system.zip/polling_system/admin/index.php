<?php
	session_start();
	
include "connection.php";
 ?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link rel="stylesheet" type="text/css" href="css/style3.css">
	<link rel="stylesheet" type="text/css" href="css/style4.css">
	<link rel="stylesheet" type="text/css" href="css/delete.css">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/login.js"></script>
	<script type="text/javascript" src="js/myjs2.js"></script>
	<script type="text/javascript" src="js/myjs3.js"></script>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	 <script>
$(function() {
$( "#datepicker" ).datepicker();
});
</script>
	<title>index</title>
</head>
<body>
	<?php
		
		if(empty($_SESSION['username']))
		{

			//require_once("login.php");
			header("location:login.php");
		}

		else
		{
			//require_once("dashboard.php");
			//include "/admin/dashboard.php";
			header("location:dashboard.php");
		}

?>
</body>
</html>