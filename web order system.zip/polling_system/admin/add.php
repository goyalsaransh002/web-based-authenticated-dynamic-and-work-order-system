<?php 
session_start();
include "connection.php";

if($_POST['poll_Id'])
{
    $poll_Id=$_POST['poll_Id'];
   	$poll_Id= mysql_escape_string($poll_Id);
}
if($_POST['title'])
{
    $title=$_POST['title'];
   	$title = mysql_escape_string($title);
}
echo "INSERT INTO options SET polls_id='$poll_Id', title='$title'";
$newrow=mysql_query("INSERT INTO options SET polls_id='$poll_Id', title='$title'");
				
if($newrow)
{
	echo "success";
}
else
{
	echo "please try again";
}

?>
<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/myjs2.js"></script>
		<script type="text/javascript" src="js/myjs3.js"></script>
</head>
<body></body>
</html>