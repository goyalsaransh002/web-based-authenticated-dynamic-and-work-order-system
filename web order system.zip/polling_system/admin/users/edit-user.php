<?php
session_start();

header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.
//echo $_SESSION['username'];
 include "../connection.php";  
?>
<?php

if(isset($_SESSION['userId']) && !empty($_SESSION['userId']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') { ?>
  <?php
    $userId = $_SESSION['userId'];
    $Id = $_GET['id'];
    $error = '';
    if(isset($Id)) {
      $user = mysql_query("SELECT * FROM users where id='$Id'");
      $result = mysql_fetch_assoc($user);
      $firstname = $result['firstname'];
      $lastname = $result['lastname'];
      $username = $result['username'];
      $email = $result['email'];
      $err_flag = true;
    if(isset($_POST['update_user'])) {
        if($firstname=="")
        {
          $err_firstname .='Please Enter First Name';
          $err_flag = false;
        }
        elseif(!ctype_alpha(str_replace(array("'", "-"), "",$firstname)))
        {
          $err_firstname .= 'First name should be alpha characters only.';
          $err_flag = false;
        }
        else
        {
          if(strlen($firstname) < 3 OR strlen($firstname) > 20)
          {
            $err_firstname .= 'First name should be within 3-20 characters long.';
            $err_flag = false;
          } else {
            $firstname = $_POST['firstname'];
          }
        }

        if($lastname=="")
        {
          $err_lastname .='Please Enter Last Name';
          $err_flag = false;
        }
        elseif(!ctype_alpha(str_replace(array("'", "-"), "", $lastname)))
        {
          $err_lastname .= 'Last name should be alpha characters only.';
          $err_flag = false;
        }
        else
        {
          if(strlen($lastname) < 3 OR strlen($lastname) > 20)
          {
            $err_lastname .= 'Last name should be within 3-20 characters long.';
            $err_flag = false;
          } else {
            $lastname = $_POST['lastname'];
          }
        }
        if($username=="")
        {
          $err_username .='Please Enter User Name';
          $err_flag = false;
        }
        elseif(!preg_match('/^([a-zA-Z])[a-zA-Z_-]*[\w_-]*[\S]$|^([a-zA-Z])[0-9_-]*[\S]$|^[a-zA-Z]*[\S]$/',$username))
        {
          $err_username .= 'Username Should Starts With An Alphabet and Contains No special Characters Other Than Underscore Or Dash.';
          $err_flag = false;
        }
        else
        {
          if(strlen($username) < 3 OR strlen($username) > 20)
          {
            $err_username .= 'Username should be within 3-20 characters long.';
            $err_flag = false;
          } else {
            $username = $_POST['username'];
          }
        }
        if($email=="")
        {
          $err_email .='Please Enter Email';
          $err_flag = false;
        }
        elseif(!preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $email))
        {
          $err_email = 'Please enter valid Email.';
          $err_flag = false;
        } else {
          $email = $_POST['email'];
        }
       
        if($err_flag) {
          $current_date = date('Y-m-d H:i:s');
          $query=mysql_query("UPDATE users SET firstname='$firstname',lastname='$lastname',username='$username',email='$email' where id='$Id'");
          
          if($query)
          {
            $success  = "User has been updated successfully.";
            header("location:users.php");
          }
          else
          {
             $error .="Something went wrong. Unable to create task";
          }

        }
      } 
    } else {
        header("location:admin/users.php");
    }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="users/edit-user.php">User</a></li>
        <li><a href="tasks/tasks.php">Tasks</a></li>
        <li><a href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="users/edit-user.php">Users</a></li>
        <li><a href="/tasks/tasks.php">Tasks</a></li>
        <li><a href="../logout.php">Logout</a></li>
      </ul><br>
    </div>
    <br>
    
    <div class="col-sm-9">
        <form method="post" action="<?php $_PHP_SELF ?>">
          <div class="form-group">
            <label for="title">First Name:</label>
            <input type="text" class="form-control" name="firstname" value="<?php echo $firstname; ?>">
            <?php if(isset($err_firstname)) { ?>
              <div class="error1"><?php echo $err_firstname; ?></div>
            <?php } ?>
          </div>
          <div class="form-group">
            <label for="pwd">Last Name:</label>
            <input type="text" class="form-control" name="lastname" value="<?php echo $lastname; ?>">
            <?php if(isset($err_lastname)) { ?>
              <div class="error1"><?php echo $err_lastname; ?></div>
            <?php } ?>
          </div>

          <div class="form-group">
              <label id="label3" class="label">Username:</label>
              <input type="text" class="form-control" id="uname" name="username" placeholder="Enter Your Username"  value="<?php echo $username; ?>" />
              <?php if(isset($err_username)) { ?>
                <div class="error1"><?php echo $err_username; ?></div>
              <?php } ?>
            </div>

            <div class="form-group">
              <label id="label4" class="label">Email:</label>
              <input type="text" class="form-control" id="email" name="email" placeholder="Enter Your Email" value="<?php echo $email; ?>" >
              <?php if(isset($err_email)) { ?>
                <div class="error1"><?php echo $err_email; ?></div>
              <?php } ?>
            </div>
  
          <button type="submit" class="btn btn-default" name="update_user">Submit</button>
        </form>
    </div>
  </div>
</div>

</nav>
</body>
</html>

<?php } else {
  header("location:login.php");
}

?>