<?php
session_start();
include "../connection.php"; 
if(isset($_SESSION['userId']) && !empty($_SESSION['userId']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') { 
	header('location:login.php');
} 
$id1=$_GET['id'];
$query=mysql_query("DELETE FROM users WHERE id='$id1' ");
header('location:users.php');
?>						
	