<?php
session_start();

header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1.
header('Pragma: no-cache'); // HTTP 1.0.
header('Expires: 0'); // Proxies.
//echo $_SESSION['username'];
 include "../connection.php";	
?>
<?php

if(isset($_SESSION['userId']) && !empty($_SESSION['userId']) && isset($_SESSION['user_type'])
  && !empty($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') { 
  $userId = $_SESSION['userId'];
  $result=mysql_query("SELECT * FROM users where user_type != 'admin'");
?>
  <!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="users.php">Users</a></li>
        <li><a href="../tasks/tasks.php">Tasks</a></li>
        <li><a href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="home.php">Dashboard</a></li>
        <li class="active"><a href="users.php">Users</a></li>
        <li><a href="../tasks/tasks.php">Tasks</a></li>
        <li><a href="../logout.php">Logout</a></li>
      </ul><br>
    </div>
    <br>
    
    <div class="col-sm-9">
        <div class='row'>
          <table class="table">
        <thead>
          <tr>
            <th>S.No</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Username</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php 
            $intTextbox=1;
            while($row = mysql_fetch_array($result)) { $id=$row['id']; ?>
              <tr class="content">
                <td id="number"><?php echo $intTextbox ; echo "<label>.</label>";
                $intTextbox++;
                ?>
                </td>
                <td id="content4"><?php echo  $row['firstname'].'<br/>'; ?></td>
                <td id="content4"><?php echo  $row['lastname'].'<br/>'; ?></td>
                <td id="content4"><?php echo  $row['email'].'<br/>'; ?></td>
                <td id="content4"><?php echo  $row['username'].'<br/>'; ?></td>
                <td id="content1">
                  <?php echo "<a href='edit-user.php?id=$id'>Edit</a>"; ?>
                  <a onclick="return confirm('Are you sure you want to delete this task?')"  href="delete-user.php?id=<?php echo $id ?>">Delete</a>
                </td>
              </tr>
            <?php } ?> 
        </tbody>
      </table>
        </div>
    </div>
  </div>
</div>

</nav>
</body>
</html>

<?php } else {
	header("location:login.php");
}

?>