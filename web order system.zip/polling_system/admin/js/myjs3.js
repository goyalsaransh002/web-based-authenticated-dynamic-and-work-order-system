 // console.log("hello");
  var intTextBox=1;
 
        //FUNCTION TO ADD TEXT BOX ELEMENT
       
        
        function addElement()
        {
             if(intTextBox>9)
         {
                alert("you can add upto 10 possible answer");
                 return false;
          }
         
             intTextBox = intTextBox + 1;
            // console.log(intTextBox);
            var contentID = document.getElementById('content');
            var newTBDiv = document.createElement('div');
            newTBDiv.setAttribute('id','text'+intTextBox);
            
            newTBDiv.innerHTML = " <input type='text' placeholder='Enter Your Choice' class='pollInput' id='textbox_" + intTextBox + "'    name=' title[] '/> <a href='javascript:removeElement(" + intTextBox + ")'>Remove</a>";
            
            contentID.appendChild(newTBDiv);
            
        
    }
        //FUNCTION TO REMOVE TEXT BOX ELEMENT
        function removeElement(id)
        {

           if(intTextBox!=1)
           {
            var contentID = document.getElementById('content');
             contentID.removeChild(document.getElementById('text'+id));

            }

        }
        