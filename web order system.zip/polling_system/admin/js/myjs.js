 $(function() {
$( "#datepicker" ).datepicker();
});