
function myfunction1()
{
	var minlength=7;
	 var password=document.forms['myform1']['password'].value;
	
	if(document.myform1.password.value=="")
	{
		alert('Please Enter Password');
		return false;
	}
	if(document.myform1.password.value.length<minlength)
	{
		alert('Please Enter Atleast 7 Character Password');
		return false;
	}

	return true;
}