$(document).ready(function() {
	var poll_Id = $('.question').attr('poll');
  	 console.log(poll_Id);
  $(document).on('change', '.pollInput', function() {
	 var str = $(this).val();
	 console.log(str);
	
  	  $.ajax({
                type:"POST",
                url:"add.php",
                data:
                 {
                 	'title':str,
                 	'poll_Id':poll_Id
                 	
                 },
                success:function(data){
                	console.log(data);
                }
            });

        });
    });
