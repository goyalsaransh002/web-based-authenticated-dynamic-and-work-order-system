$(document).ready(function() {
	var poll = $('.question').attr('poll');
  $(".pollRemove").on("click", function(){

  	var pollId = $(this).attr('pollId');
  	$(this).parent().detach();
  	$.ajax({
		type: "GET",
		url: "deleteCourse.php",
		data: { pollId: pollId,
				poll:poll 
				 },
		success: function(data) {
            console.log(data);
		}
		
	});

   });

});