console.log("hi");
function myfunction()
{
	var minlength=7;
	 var username=document.forms["myform"]["username"].value;
	// var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
	 var password=document.forms["myform"]["password"].value;
	 //var reg1="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	 if(username=="" || username==null)
	 {
	 	
	 	alert("Please Enter Username Name");
	 	return false;
	 }
	/* if (!reg.test(login))
	 {
		alert("invalid email");
		return false;
	} */
	
	if(document.myform.password.value=="")
	{
		alert("Please Enter Password");
		return false;
	}
	if(document.myform.password.value.length<minlength)
	{
		alert("Please Enter Atleast 7 Character Password");
		return false;
	}

	return true;
}