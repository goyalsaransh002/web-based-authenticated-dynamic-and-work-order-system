console.log("hi");
function myfunction1()
{
	var Email=document.forms['myform1']['Email'].value;
	 var emailRegexStr = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  	 var isvalid = emailRegexStr.test(Email); 
	
		if(Email=="")
	{
		alert('Required Email');
		return false;
	}
	if (!isvalid) {
 		alert('Invalid Email Address!');
 		return false;
 	}
	

	return true;
}