//console.log("hi");

function myfunction()
{
	
	var poll_title=document.forms["myform"]["poll_title"].value;
//	var title=document.forms["myform"]["title[]"].value;
	var StartDate= document.forms["myform"]["txtStartDate"].value;
 	var EndDate= document.forms["myform"]["txtEndDate"].value;
	
	if(poll_title=="")
	{
		alert("Please Provide Details!");
		return false;
	}

	if(!isNaN(poll_title))
	{
		alert('Please Enter Alphabets');
		return false;
	}
	
	var numItems = $('.pollInput').length;
	if(numItems<2) {
		alert("Please Enter Atleast Two Choices");
		return false;
	}
	 var tb = document.getElementsByClassName("pollInput");
        for (var i = 0; i < tb.length; i++) {
            if (tb[i].type == "text") {
                var txtValue = tb[i].value;
                if (txtValue == "") {
                    alert("Please Enter Some Data");
                	return false;
                    
                }
            }
        }
     /*   $('input[name^="title"]').change(function() {

    var $current = $(this);

    $('input[name^="title"]').each(function() {
        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id'))
        {
            alert('duplicate found!');
        }

    });
  });*/
var answers = document.getElementsByClassName("pollInput");
var seen = {};

  for (var i=0;i<answers.length;i++) { 
    if (seen[ answers[i].value ]) { 
      alert("Duplicate Data "); 
      return false;
    } 
    seen[answers[i].value] = true; 
  }
 
  if(StartDate!= '' && StartDate!= '' && StartDate>EndDate)
    {
	    alert("Please Ensure That The End Date Is Greater Than Or Equal To The Start Date.");
	    return false;
    }

  if(StartDate=="")
  {
  	alert('Start Date Should Be Filled Out');
  	return false;
  }
  if(EndDate=="")
  {
  	alert('End Date Should Be Filled Out');
  	return false; 
  }
	return true;
}
