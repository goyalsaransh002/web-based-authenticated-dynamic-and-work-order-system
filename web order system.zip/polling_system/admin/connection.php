<?php
		
		$con=mysql_connect("localhost","root","","my_db");
		if(!($con))
		{
			echo "failed to connect";
		} 
	
		mysql_select_db('my_db');
		
?>